<?php
    header("location:xac-minh-ban-be/");
?>