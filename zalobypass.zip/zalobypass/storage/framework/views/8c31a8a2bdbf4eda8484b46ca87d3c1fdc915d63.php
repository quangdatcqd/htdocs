  <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
          <li class="nav-item   <?php echo $__env->yieldContent('home-active'); ?>  ">
              <a class="nav-link" href="<?php echo e(route('home')); ?>">Trang chủ <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item <?php echo $__env->yieldContent('category-active'); ?> category-nav">
              <a class="nav-link">Danh mục <span class="sr-only">(current)</span></a>
              <?php echo $__env->make('category.categories_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </li>
          <li class="nav-item <?php echo $__env->yieldContent('new-active'); ?>">
              <a class="nav-link" href="single.html">Tin mới nhất <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item <?php echo $__env->yieldContent('new-active'); ?>">
              <a class="nav-link" href="single.html">Tin nổi bật <span class="sr-only">(current)</span></a>
          </li>

          <li class="nav-item <?php echo $__env->yieldContent('new-active'); ?>">
              <a class="nav-link" href="Contact_us.html">Liên hệ <span class="sr-only">(current)</span></a>
          </li>
      </ul>

  </div>
<?php /**PATH C:\xampp\htdocs\fast-new-client\resources\views/layouts/menu.blade.php ENDPATH**/ ?>