<div class="container text-uppercase mt-4">
    <a href="<?php echo e(route('home')); ?>"><i class="fa fa-home"></i></a> > <a
        href="<?php echo e(route('category.show', ['id' => $parentCategory->slug])); ?>">
        <?php echo e($parentCategory->name); ?></a>
    > <a href="<?php echo e(route('category.show', ['id' => $post->category->slug])); ?>"><?php echo e($post->category->name); ?></a>
</div>
<div class="container  my-1">
    <a href="<?php echo e(route('home')); ?>"><i class="fa fa-user"></i> <?php echo e($post->user->name); ?></a> &nbsp;&nbsp;~&nbsp;&nbsp;
    <span
        class=""><?php echo e(\Carbon\Carbon::parse($post->created_at)->format('d-m-Y - h:m')); ?></span>&nbsp;&nbsp;~&nbsp;&nbsp;
    <i class=""> <b><?php echo e($post->views); ?> </b> lượt xem</i>
</div>

<div id="fh5co-single-content" class="container-fluid pb-4 pt-4 paddding">
    <div class="container paddding">

        <div class="mx-auto row  ">
            <div class="col-md-8 animate-box" data-animate-effect="fadeInLeft">
                <div class="title-post">
                    <h1 class="title-post"> <?php echo e($post->title); ?></h1>
                </div>
                <div class="my-3 list-group-item h6">
                    <i>
                        <h2 class="description-post"><?php echo e($post->description); ?></h2>
                    </i>
                </div>
                <div class="content  ">
                    <?php echo $post->content; ?>

                </div>
                <div class="fh5co_tags_all">
                    <b> Từ khoá:</b>
                    <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="" class="fh5co_tagg"><?php echo e($tag->title); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
            <div class="col-md-3 animate-box" data-animate-effect="fadeInRight">
                <?php echo $__env->make('home.tags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php /**PATH C:\xampp\htdocs\fast-new-client\resources\views/detail/content.blade.php ENDPATH**/ ?>