<div class="container-fluid paddding mb-5">
    <div class="row mx-0">
        <div class="col-md-6 col-12 paddding animate-box" data-animate-effect="fadeIn">
            <div class="fh5co_suceefh5co_height"><img src="images/nick-karvounis-78711.jpg" alt="img" />
                <div class="fh5co_suceefh5co_height_position_absolute"></div>
                <div class="fh5co_suceefh5co_height_position_absolute_font">
                    <div class=""><a class="color_fff"> <i class="fa fa-clock-o"></i>&nbsp;&nbsp;
                            <?php echo e(\Carbon\Carbon::parse($posts[0]->created_at)->format('d-m-Y')); ?>

                        </a>
                        |
                        <a class="category-name"
                            href="<?php echo e(route('category.show', ['id' => $posts[0]->category->slug])); ?>"><?php echo e($posts[0]->category->name); ?>

                        </a>
                    </div>
                    <div class="">
                        <a href="<?php echo e(route('post.show', ['id' => $posts[0]->slug])); ?>" class="fh5co_good_font">
                            <?php echo e($posts[0]->title); ?>

                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-6 col-6 paddding animate-box" data-animate-effect="fadeIn">
                    <div class="fh5co_suceefh5co_height_2"><img src="images/science-578x362.jpg" alt="img" />
                        <div class="fh5co_suceefh5co_height_position_absolute"></div>
                        <div class="fh5co_suceefh5co_height_position_absolute_font_2">
                            <div class="">
                                <a class="color_fff"> <i class="fa fa-clock-o"></i>&nbsp;&nbsp;
                                    <?php echo e(\Carbon\Carbon::parse($posts[1]->created_at)->format('d-m-Y')); ?>

                                </a>
                                |
                                <a class="category-name"
                                    href="<?php echo e(route('category.show', ['id' => $posts[1]->category->slug])); ?>"><?php echo e($posts[1]->category->name); ?>

                                </a>
                            </div>
                            <div class="">
                                <a href="<?php echo e(route('post.show', ['id' => $posts[1]->slug])); ?>"
                                    class="fh5co_good_font w-100">
                                    <?php echo e($posts[1]->title); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-6 paddding animate-box" data-animate-effect="fadeIn">
                    <div class="fh5co_suceefh5co_height_2"><img src="images/joe-gardner-75333.jpg" alt="img" />
                        <div class="fh5co_suceefh5co_height_position_absolute"></div>
                        <div class="fh5co_suceefh5co_height_position_absolute_font_2">
                            <div class="">
                                <a class="color_fff"> <i class="fa fa-clock-o"></i>&nbsp;&nbsp;
                                    <?php echo e(\Carbon\Carbon::parse($posts[2]->created_at)->format('d-m-Y')); ?>

                                </a>
                                |
                                <a class="category-name"
                                    href="<?php echo e(route('category.show', ['id' => $posts[2]->category->slug])); ?>"><?php echo e($posts[2]->category->name); ?>

                                </a>
                            </div>
                            <div class="">
                                <a href="<?php echo e(route('post.show', ['id' => $posts[2]->slug])); ?>"
                                    class="fh5co_good_font w-100">
                                    <?php echo e($posts[2]->title); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-6 paddding animate-box" data-animate-effect="fadeIn">
                    <div class="fh5co_suceefh5co_height_2"><img src="images/ryan-moreno-98837.jpg" alt="img" />
                        <div class="fh5co_suceefh5co_height_position_absolute"></div>
                        <div class="fh5co_suceefh5co_height_position_absolute_font_2">
                            <div class="">
                                <a class="color_fff"> <i class="fa fa-clock-o"></i>&nbsp;&nbsp;
                                    <?php echo e(\Carbon\Carbon::parse($posts[3]->created_at)->format('d-m-Y')); ?>

                                </a>
                                |
                                <a class="category-name"
                                    href="<?php echo e(route('category.show', ['id' => $posts[3]->category->slug])); ?>"><?php echo e($posts[3]->category->name); ?>

                                </a>
                            </div>
                            <div class="">
                                <a href="<?php echo e(route('post.show', ['id' => $posts[3]->slug])); ?>"
                                    class="fh5co_good_font w-100">
                                    <?php echo e($posts[3]->title); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-6 paddding animate-box" data-animate-effect="fadeIn">
                    <div class="fh5co_suceefh5co_height_2"><img src="images/10-1-1-875x500.jpg" alt="img" />
                        <div class="fh5co_suceefh5co_height_position_absolute"></div>
                        <div class="fh5co_suceefh5co_height_position_absolute_font_2">
                            <div class="">
                                <a class="color_fff"> <i class="fa fa-clock-o"></i>&nbsp;&nbsp;
                                    <?php echo e(\Carbon\Carbon::parse($posts[4]->created_at)->format('d-m-Y')); ?>

                                </a>
                                |
                                <a class="category-name"
                                    href="<?php echo e(route('category.show', ['id' => $posts[4]->category->slug])); ?>"><?php echo e($posts[4]->category->name); ?>

                                </a>
                            </div>
                            <div class="">
                                <a href="<?php echo e(route('post.show', ['id' => $posts[4]->slug])); ?>"
                                    class="fh5co_good_font w-100">
                                    <?php echo e($posts[4]->title); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\fast-new-client\resources\views/home/newposts.blade.php ENDPATH**/ ?>