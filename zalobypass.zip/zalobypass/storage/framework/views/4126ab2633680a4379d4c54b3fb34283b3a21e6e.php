<div class="container-fluid pb-3 pt-3">
    <div class="container animate-box" data-animate-effect="fadeIn">
        <div>
            <div class="fh5co_heading fh5co_heading_border_bottom py-2 mb-4">Tin nổi bật</div>
        </div>
        <div class="owl-carousel owl-theme js" id="slider1">
            <?php $__currentLoopData = $highLightPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item px-2">
                    <div class="fh5co_latest_trading_img_position_relative">
                        <div class="fh5co_latest_trading_img"><img src="<?php echo e($post->thumbnail); ?>" alt=""
                                class="fh5co_img_special_relative" /></div>
                        <div class="fh5co_latest_trading_img_position_absolute"></div>
                        <div class="fh5co_latest_trading_img_position_absolute_1">
                            <a href="<?php echo e(route('post.show', ['id' => $post->slug])); ?>" class="text-white">
                                <?php echo e($post->title); ?>

                            </a>
                            <div class="fh5co_latest_trading_date_and_name_color">
                                <i class="fa fa-user-o"></i>
                                <a href="">
                                    <?php echo e($post->user->name); ?>

                                </a>
                                |
                                <a href="<?php echo e(route('category.show', ['id' => $post->category->slug])); ?>">
                                    <?php echo e($post->category->name); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\fast-new-client\resources\views/home/highlight_posts.blade.php ENDPATH**/ ?>