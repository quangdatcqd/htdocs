 <?php if($paginator->hasPages()): ?>
     <div class="row mx-0 animate-box" data-animate-effect="fadeInUp">
         <div class="col-12 text-center pb-4 pt-4">

             <?php if($paginator->onFirstPage()): ?>
                 <a class="btn_mange_pagging disabled"><i class="fa fa-long-arrow-left"></i>
                 </a>
             <?php else: ?>
                 <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="btn_mange_pagging"><i
                         class="fa fa-long-arrow-left"></i>
                 </a>
             <?php endif; ?>
             
             <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                 <?php if(is_string($element)): ?>
                     <a class="btn_mange_pagging disabled">
                         <?php echo e($element); ?></a>
                 <?php endif; ?>

                 
                 <?php if(is_array($element)): ?>
                     <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php if($page == $paginator->currentPage()): ?>
                             <a class="btn_mange_pagging actived"> <?php echo e($page); ?></a>
                         <?php else: ?>
                             <a href="<?php echo e($url); ?>" class="btn_pagging"><?php echo e($page); ?></a>
                         <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
             <?php if($paginator->hasMorePages()): ?>
                 <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="btn_mange_pagging "> <i
                         class="fa fa-long-arrow-right"></i>
                 </a>
             <?php else: ?>
                 <a class="btn_mange_pagging disabled"> <i class="fa fa-long-arrow-right"></i>
                 </a>
             <?php endif; ?>

         </div>
     </div>
 <?php endif; ?>
<?php /**PATH C:\xampp\htdocs\fast-new-client\resources\views/vendor/pagination/default.blade.php ENDPATH**/ ?>