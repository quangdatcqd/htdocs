<div class="container-fluid pb-1 pt-4 paddding">
    <div class="container paddding">
        <div class="row mx-0">
            <div class="col-md-8 animate-box" data-animate-effect="fadeInLeft">
                <div>
                    <div class="fh5co_heading fh5co_heading_border_bottom py-2 mb-4">XÃ HỘI</div>
                </div>
                <?php $__currentLoopData = $category1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row pb-4">
                        <div class="col-md-5">
                            <div class="fh5co_hover_news_img">
                                <div class="fh5co_news_img"><img src="<?php echo e($post->thumbnail); ?>" alt="" />
                                </div>
                                <div></div>
                            </div>
                        </div>
                        <div class="col-md-7 animate-box">
                            <div>
                                <a href="<?php echo e(route('post.show', ['id' => $post->slug])); ?>" class="fh5co_magna py-2">
                                    <?php echo e($post->title); ?>

                                </a>
                            </div>
                            <div class="py-1">
                                <a href="single.html" class="fh5co_mini_time py-0"><i class="fa fa-user-o"></i>
                                    <?php echo e($post->user->name); ?> -
                                    <?php echo e(\Carbon\Carbon::parse($post->created_at)->format('d-m-Y')); ?> </a>
                            </div>

                            <div class="fh5co_consectetur">
                                <?php echo e($post->description); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-3 animate-box" data-animate-effect="fadeInRight">
                <?php echo $__env->make('home.tags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\fast-new-client\resources\views/home/category1_posts.blade.php ENDPATH**/ ?>