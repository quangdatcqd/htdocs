
<?php $__env->startSection('title', 'Danh mục'); ?>
<?php $__env->startSection('category-active', 'active'); ?>
<?php $__env->startSection('main'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fast-new-client\resources\views/category/index.blade.php ENDPATH**/ ?>