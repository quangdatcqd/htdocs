<div>
    <div class="fh5co_heading fh5co_heading_border_bottom py-2 mb-4">Tìm theo từ khoá</div>
</div>
<div class="clearfix"></div>
<div class="fh5co_tags_all">
    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="#" class="fh5co_tagg"><?php echo e($tag->title); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\fast-new-client\resources\views/home/tags.blade.php ENDPATH**/ ?>