<div id="fh5co-title-box" style="background-image: url(<?php echo e($post->thumbnail); ?>); background-position: 50% 90.5px;"
    data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="page-title">
        <img src="<?php echo e($post->thumbnail); ?>" alt="cqd">
        <span>January 1, 2018</span>
        <h2><?php echo e($post->title); ?></h2>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\fast-new-client\resources\views/detail/post_banner.blade.php ENDPATH**/ ?>