<div class="container mb-4 mt-2  bg-light py-3 pb-5 categories-container ">
    
    <div class="row">

        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($parent->parent_id == null): ?>
                <div class="col-md-3 box-categories">
                    <p> <a href="<?php echo e(route('category.show', ['id' => $parent->slug])); ?>"><?php echo e($parent->name); ?></a></p>
                    <ul class="pl-3">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($category->parent_id == $parent->id): ?>
                                <li>
                                    <a href="<?php echo e(route('category.show', ['id' => $category->slug])); ?>"><?php echo e($category->name); ?>

                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\fast-new-client\resources\views/category/categories_list.blade.php ENDPATH**/ ?>