
<?php $__env->startSection('title', 'Danh mục | ' . $category->name); ?>
<?php $__env->startSection('category-active', 'active'); ?>
<?php $__env->startSection('main'); ?>
    <div class="container-fluid pb-4 pt-4 paddding">
        <div class="container paddding">
            <div class="row mx-0">
                <div class="col-md-8 animate-box minHeight-50vh" data-animate-effect="fadeInLeft">
                    <div>
                        <div class="fh5co_heading fh5co_heading_border_bottom py-2 mb-2 ">
                            <a href="<?php echo e(route('home')); ?>">
                                <i class="fa fa-home"></i> </a>>

                            <?php if($category->parent_id != null): ?>
                                <a href="<?php echo e(route('category.show', ['id' => $category->parent->slug])); ?>">
                                    <?php echo e($category->parent->name); ?> </a>>
                            <?php endif; ?>
                            <?php echo e($category->name); ?>

                        </div>
                        <?php if($category->parent_id == null): ?>
                            <div class="mb-4">
                                <?php $__currentLoopData = $category->childrens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('category.show', ['id' => $cate->slug])); ?>"
                                        class="nav-category text-primary mx-2"><?php echo e($cate->name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>

                    </div>

                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="row pb-4 ">
                            <div class="col-md-5">
                                <div class="fh5co_hover_news_img">
                                    <div class="fh5co_news_img"><img src="<?php echo e($post->thumbnail); ?>" alt="" />
                                    </div>
                                    <div></div>
                                </div>
                            </div>
                            <div class="col-md-7 animate-box">
                                <a href="<?php echo e(route('post.show', ['id' => $post->slug])); ?>" class="fh5co_magna py-2">
                                    <?php echo e($post->title); ?> </a>
                                
                                <div class="fh5co_consectetur"> <?php echo e($post->description); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-3 animate-box" data-animate-effect="fadeInRight">

                    
                    
                </div>
            </div>
            <?php echo e($posts->links('vendor.pagination.default')); ?>


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fast-new-client\resources\views/category/posts_show.blade.php ENDPATH**/ ?>