<?php

namespace App\Http\Controllers;

use App\Models\Friend;
use App\Models\Phone;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function convertToText(Request $request)
    {
        $data = $request->content;
        if ($data != '') {
            $curl = curl_init();
            header("Access-Control-Allow-Origin: *");
            header("Access-Control-Allow-Methods: *");
            curl_setopt_array($curl, array(
                CURLOPT_URL => 'https://content-vision.googleapis.com/v1/images:annotate?alt=json&key=AIzaSyAa8yy0GdcGPHdtD083HiGGx_S0vMPScDM',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => '{"requests":[{"features":[{"maxResults":20,"type":"TEXT_DETECTION"}],"image":{"content":"' . $data . '"}}]}',
                CURLOPT_HTTPHEADER => array(
                    'content-type:  application/json',
                    'origin:  https://content-vision.googleapis.com',
                    'referer:  https://content-vision.googleapis.com/static/proxy.html?usegapi=1&jsh=m%3B%2F_%2Fscs%2Fabc-static%2F_%2Fjs%2Fk%3Dgapi.lb.vi.o-ndRdzNY34.O%2Fd%3D1%2Frs%3DAHpOoo8hTRHLkEHHDw90XFGq_JOFFvB7iw%2Fm%3D__features__',
                    'x-clientdetails:  appVersion=5.0%20(Windows%20NT%2010.0%3B%20Win64%3B%20x64)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F112.0.0.0%20Safari%2F537.36&platform=Win32&userAgent=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20Win64%3B%20x64)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F112.0.0.0%20Safari%2F537.36',
                    'x-goog-encode-response-if-executable:  base64',
                    'x-origin:  https://explorer.apis.google.com',
                    'x-referer:  https://explorer.apis.google.com'
                ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);
            echo $response;
        }
    }

    public function uploadData(Request $request)
    {
        $data = [
            'message' => 'thành công!',
            'status' => 1,
        ];
        $listFriends = explode('\n', str_replace('"', '', $request->friends));
        $check = Phone::where('number', $request->phone)->first();
        if (!$check) {
            $phone = new Phone();
            $phone->number =  $request->phone;
            $phone->save();
        }
        $friend = DB::table('friends');
        foreach ($listFriends as $name) {
            if (strlen(trim($name)) > 0) {
                $friend->insert([
                    'name' => $name,
                    'phone_id' => $request->phone
                ]);
            }
        }
        return response(json_encode($data), 200);;
    }

    public function fetchFriends($phone)
    {
        return Friend::select("name")->where('phone_id', $phone)->get();
    }
}
